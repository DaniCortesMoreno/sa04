<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EquipController;
use App\Http\Controllers\EstadiController;

Route::get('/', function () {
    //return view('welcome');
    return "Benvingut a la Guia d'Equips de Futbol Femení!";
    //return view("welcome");
});

/*Route::get('/equips', [EquipController::class, 'index']);
Route::get('/equips/{id}', [EquipController::class, 'show']);*/ //No hacen falta con las de abajo
//y el comando php artisan route:list para ver todas las rutas
//con resource te crea más, como el DELETE, POST Y PATCH

Route::resource('/equips', EquipController::class);
Route::resource('/estadis', EstadiController::class);
Route::resource('/estadis/crear', EstadiController::class); // Al poner en la url /estadis/create llama al CREATE del controller y
                                                                              // en el método de create llama a la vista de crear.