<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Guia de futbol femení'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>
<body class="font-sans bg-gray-100 text-gray-900">
<header class="bg-blue-800 text-white p-4">
    <?php echo $__env->make('partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<main class="container mx-auto p-6">
    <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="bg-blue-800 text-white text-center p-4">
    <p>&copy; 2024 Guia de Futbol Femení</p>
</footer>
</body>
</html><?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>