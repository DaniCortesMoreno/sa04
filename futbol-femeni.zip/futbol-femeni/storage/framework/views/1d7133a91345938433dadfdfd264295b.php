<?php $__env->startSection('title', "Guia d'Equips"); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-bold text-blue-800 mb-6">Guia d'Equips</h1>
<table class="w-full border-collapse border border-gray-300">
    <thead class="bg-gray-200">
    <tr>
        <th class="border border-gray-300 p-2">Nom</th>
        <th class="border border-gray-300 p-2">Estadi</th>
        <th class="border border-gray-300 p-2">Títols</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $equips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $equip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="hover:bg-gray-100">
        <td class="border border-gray-300 p-2">
            <a href="<?php echo e(route('equips.show', $key)); ?>" class="text-blue-700 hover:underline"><?php echo e($equip['nom']); ?></a>
        </td>
        <td class="border border-gray-300 p-2"><?php echo e($equip['estadi']); ?></td>
        <td class="border border-gray-300 p-2"><?php echo e($equip['titols']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/equips/index.blade.php ENDPATH**/ ?>