<?php $__env->startSection('title', "Pàgina equip femení" ); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginala142a8fe3aec424f14b9e20ec5987af2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala142a8fe3aec424f14b9e20ec5987af2 = $attributes; } ?>
<?php $component = App\View\Components\Equip::resolve(['nom' => $equip['nom'],'estadi' => $equip['estadi'],'titols' => $equip['titols']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('equip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Equip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala142a8fe3aec424f14b9e20ec5987af2)): ?>
<?php $attributes = $__attributesOriginala142a8fe3aec424f14b9e20ec5987af2; ?>
<?php unset($__attributesOriginala142a8fe3aec424f14b9e20ec5987af2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala142a8fe3aec424f14b9e20ec5987af2)): ?>
<?php $component = $__componentOriginala142a8fe3aec424f14b9e20ec5987af2; ?>
<?php unset($__componentOriginala142a8fe3aec424f14b9e20ec5987af2); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/equips/show.blade.php ENDPATH**/ ?>