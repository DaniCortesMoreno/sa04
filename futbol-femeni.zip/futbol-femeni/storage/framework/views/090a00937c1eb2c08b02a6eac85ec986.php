<div class="equip border rounded-lg shadow-md p-4 bg-white">
    <h2 class="text-xl font-bold text-blue-800"><?php echo e($nom); ?></h2>
    <p><strong>Ciutat:</strong> <?php echo e($ciutat); ?></p>
    <p><strong>Capacitat:</strong> <?php echo e($capacitat); ?></p>
    <p><strong>Equip Principal:</strong> <?php echo e($equipPrincipal); ?></p>
</div><?php /**PATH /var/www/html/resources/views/components/estadi.blade.php ENDPATH**/ ?>