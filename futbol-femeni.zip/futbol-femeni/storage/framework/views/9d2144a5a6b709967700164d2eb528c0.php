<div class="equip border rounded-lg shadow-md p-4 bg-white">
    <h2 class="text-xl font-bold text-blue-800"><?php echo e($nom); ?></h2>
    <p><strong>Estadi:</strong> <?php echo e($estadi); ?></p>
    <p><strong>Títols:</strong> <?php echo e($titols); ?></p>
</div><?php /**PATH /var/www/html/resources/views/components/equip.blade.php ENDPATH**/ ?>