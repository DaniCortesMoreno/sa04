<?php $__env->startSection('title', "Guia d'Equips"); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-bold text-blue-800 mb-6">Guia d'Equips</h1>
<table class="w-full border-collapse border border-gray-300">
    <thead class="bg-gray-200">
    <tr>
        <th class="border border-gray-300 p-2">Nom</th>
        <th class="border border-gray-300 p-2">Ciutat</th>
        <th class="border border-gray-300 p-2">Capacitat</th>
        <th class="border border-gray-300 p-2">Equip Principal</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $estadis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $estadi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="hover:bg-gray-100">
        <td class="border border-gray-300 p-2">
            <a href="<?php echo e(route('estadis.show', $key)); ?>" class="text-blue-700 hover:underline"><?php echo e($estadi['nom']); ?></a>
        </td>
        <td class="border border-gray-300 p-2"><?php echo e($estadi['ciutat']); ?></td>
        <td class="border border-gray-300 p-2"><?php echo e($estadi['capacitat']); ?></td>
        <td class="border border-gray-300 p-2"><?php echo e($estadi['equipPrincipal']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/estadis/index.blade.php ENDPATH**/ ?>