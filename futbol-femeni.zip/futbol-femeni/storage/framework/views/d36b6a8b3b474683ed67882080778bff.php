<?php $__env->startSection('title', "Pàgina estadi femení" ); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal38c2e2dceb95219248d124a8428cf403 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38c2e2dceb95219248d124a8428cf403 = $attributes; } ?>
<?php $component = App\View\Components\Estadi::resolve(['nom' => $estadi['nom'],'ciutat' => $estadi['ciutat'],'capacitat' => $estadi['capacitat'],'equipPrincipal' => $estadi['equipPrincipal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('estadi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Estadi::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38c2e2dceb95219248d124a8428cf403)): ?>
<?php $attributes = $__attributesOriginal38c2e2dceb95219248d124a8428cf403; ?>
<?php unset($__attributesOriginal38c2e2dceb95219248d124a8428cf403); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38c2e2dceb95219248d124a8428cf403)): ?>
<?php $component = $__componentOriginal38c2e2dceb95219248d124a8428cf403; ?>
<?php unset($__componentOriginal38c2e2dceb95219248d124a8428cf403); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/estadis/show.blade.php ENDPATH**/ ?>