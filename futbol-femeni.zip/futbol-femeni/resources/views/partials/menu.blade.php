<nav>
    <ul class="flex space-x-4">
        <li><a href="/" class="text-white hover:underline">Inici</a></li>
        <li><a href="/equips" class="text-white hover:underline">Guia d'Equips</a></li>
        <li><a href="/estadis" class="text-white hover:underline">Llistat d'Estadis</a></li>
    </ul>
</nav>